/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lucas_q3;

import java.util.Scanner;

/**
 *
 * @author lramos
 */
public class LUCAS_Q3 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        System.out.println("Olá essas sao nossas opcões de café");
        System.out.println("\n1 - café expresso");
        System.out.println("\n2 - café capuccino");
        System.out.println("\n3 - leite com café");
        
        System.out.println("Digite o numero da opção que voce deseja");
        int opcao = ler.nextInt();
        
      
        int a = 1; 
        int b= 2;
        int c=3;
        int d;
        
        double g = 0.75;
        double e = 1.00;
        double f = 1.25;
           
        double caixa = 0;
        
       { 
        if(opcao == 1)
           
           System.out.println("o valor da venda foi R$"+g);
       
        {
         if (opcao ==2)
          System.out.println("o valor da venda foi R$"+e);
         
         {  
         if (opcao == 3)
              System.out.println("o valor da venda foi R$ "+f);
        
           
         {
             if (opcao == 4)
                 System.out.println("o valor das vendas e R$"+ caixa );
         return;
         }
    }  
}    
       }
    }
    }
           
             
             
             
             
                          
       
          
              
           

    

