/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lucas_q2;

import java.util.Scanner;

/**
 *
 * @author lramos
 */
public class LUCAS_Q2 {

    public static void main(String[] args) {
        
        
        Scanner ler = new Scanner(System.in);
        
        
        System.out.println("Digite sua idade dividida em anos,meses e dias  ");
        System.out.println("Digite em anos");
          int anos =ler.nextInt();
        System.out.println("Digite em meses");
          int meses = ler.nextInt();
          System.out.println("Digite em dias");
          int dias = ler.nextInt();
          
       int total;
        int a ;
        int m;
     
        a=365;
        m=30;
        
        
        
        
        total = (dias+(anos*a)+(meses*m));
 
        
        System.out.println("Voce tem " + anos +" anos,"+ meses+ " meses e "+ dias+ " dias " + " = "+  total + " dias");
    }   
}


        
    

