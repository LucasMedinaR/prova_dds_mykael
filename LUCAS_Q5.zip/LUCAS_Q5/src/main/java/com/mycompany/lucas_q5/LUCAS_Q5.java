/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lucas_q5;

import java.util.Scanner;

/**
 *
 * @author lramos
 */
public class LUCAS_Q5 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        
        System.out.println("Olá digite o codigo");  
        int codigo1 = ler.nextInt();
        
        
        
        
        
        
        int senha;
        int codigo;
        
        
        senha = 9999;
        codigo = 1234;
        {   
      if(codigo1 == codigo);
         
      else {
          System.out.println("Usuário inválido!.");
                  return;
      
      }
        }
      
             
                
    
        
                  
    
      System.out.println("Agora digite a senha");
         int senha1 = ler.nextInt();
         { 
         if(senha1 == senha)
         System.out.println("Acesso liberado");
                    
         
            else  
                    System.out.println("senha incorreta");
                    return;
         }
    }
    
         }

    

